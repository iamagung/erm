<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Libraries\compressFile;
use App\Model\Identitas;
// use App\Model\Profil;
// use App\Model\Galeri;
use App\Model\User;



// Sistem Administrasi & Neraca Scaffolding
use Redirect, Auth, Hash, DB, Session;

date_default_timezone_set('Asia/Jakarta');

class unsetController extends Controller
{
  function main(Request $request){
    $rute = '';
    if(Auth::User()->level=='2'){
      DB::table('rekap_medik')->where('id_rekapMedik',Session::get('id_rekap'))->update(['aksi_dokter'=>'1']);
      DB::table('rekap_medik')->where('id_rekapMedik',Session::get('id_rekap'))->update(['jenis_kasus'=>null]);
      $rute = 'rekam_new_all';
    }else if(Auth::User()->level=='3'){
      DB::table('rekap_medik')->where('id_rekapMedik',Session::get('id_rekap'))->update(['aksi_perawat'=>'1', 'aksi_terapis'=>'1', 'nama_terapis'=>auth::user()->nama_terapis, 'aksi_dokter' => '0']);
      DB::table('rekap_medik')->where('id_rekapMedik',Session::get('id_rekap'))->update(['jenis_kasus'=>null]);
      $rute = 'dataRegistrasiPerawat';
    }else{
    }
    $return = redirect()->route($rute)->with('title','Terima Kasih !')->with('message','Data telah disimpan')->with('type','success');
    Session::forget('no_RM');
    Session::forget('id_rekap');
    return $return;
  }
}
