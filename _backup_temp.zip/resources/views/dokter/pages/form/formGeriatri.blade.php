<div class="row">
    <label for="hide_geriatri"><span style="font-weight:20px;font-size:18px">Pengkajian Paripurna</span></label>
    <a href="javascript:void(0)" class="btn-danger" style="padding-left:10px; padding-right:10px;" id="hide_geriatri">Tidak Jadi</a>
</div>
<div class="clearfix" style="margin-bottom: 10px"></div>