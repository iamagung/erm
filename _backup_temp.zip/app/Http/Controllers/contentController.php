<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Libraries\compressFile;
use App\Model\Identitas;
// use App\Model\Profil;
// use App\Model\Galeri;
use App\Model\User;
use Illuminate\Support\Facades\Schema;
// Sistem Administrasi & Neraca Scaffolding
use Redirect, Auth, Hash, DB, Session;

date_default_timezone_set('Asia/Jakarta');

class contentController extends Controller
{
    function content1(){
        if(Auth::User()->level=='1'){
            $dokter = '';
            $view = 'admin.pages.add.content';
            $include = 'admin.pages.add.content.tahap1';
        }else if(Auth::User()->level=='2'){
            $dokter = DB::table('login_dokter as l')->join('users as u','u.id','l.user_id')->where('u.id',Auth::User()->id)->first();
            $view = 'dokter.pages.add.content';
            $include = 'dokter.pages.add.content.tahap1';
        }else if(Auth::User()->level=='3'){
            $dokter = DB::table('users')->where('id',Auth::User()->id)->first();
            $view = 'perawat.pages.add.content';
            $include = 'perawat.pages.add.content.tahap1';
        }
        $data = [
            'identitas'=>Identitas::find(1),
            'active'=>'2',
            'active_sub'=>'',
            'dokter'=>$dokter,
            'content'=>'1',
            'title'=>'Syarat dan Ketentuan',
            'include'=>$include,
        ];
        return view($view,$data);
    }

    function content2_so_data(Request $request){
        $data = DB::connection('rsu')->table('tr_rawatjalantindakan_d')->get();

        return ['status' => 'success', 'data' => $data];
    }

    function content2(){
        $form_kebidanan = [];
        $form_terapi_wicara = [];
        $form_okupasi_terapi = [];
        $form_orthotik = []; 
        $form_fisioterapi = []; 

        if(Auth::User()->level=='1'){
            $dokter = '';
            $view = 'admin.pages.add.content';
            $include = 'admin.pages.add.content.tahap3';
        }else if(Auth::User()->level=='2'){
            $dokter = DB::table('login_dokter as l')->join('users as u','u.id','l.user_id')->where('u.id',Auth::User()->id)->first();
            $view = 'dokter.pages.add.content';
            $include = 'dokter.pages.add.content.tahap3';
        }else if(Auth::User()->level=='3'){
            $dokter = DB::table('users')->where('id',Auth::User()->id)->first();
            $view = 'perawat.pages.add.content';
            $include = 'perawat.pages.add.content.tahap3';
            //kebutuhan form rehab (okupasi terapi,terapi wicara, orthotik)
            if (Auth::user()->is_terapis == 'Y') {
                $form_fisioterapi = Schema::getColumnListing('rekam_medis_fisioterapi');
                $form_terapi_wicara = Schema::getColumnListing('rekam_medis_terapi_wicara');
                $form_okupasi_terapi = Schema::getColumnListing('rekam_medis_okupasi_terapi');
                $form_orthotik = Schema::getColumnListing('rekam_medis_orthotik');
            }
        }
        $rekap1 = DB::table('rekap_medik')
            ->where('no_RM', Session::get('no_RM'))
            ->orderBy('tanggalKunjungan','DESC')
            ->paginate(10);

        /* kebutuhan form */
        $data_fisioterapi = DB::table('rekam_medis_fisioterapi')
            ->where('rekapMedik_id', Session::get('id_rekap') )
            ->orderBy('id_form_fisioterapi', 'DESC')
            ->first();
        $data_terapi_wicara = DB::table('rekam_medis_terapi_wicara')
            ->where('rekapMedik_id', Session::get('id_rekap') )
            ->orderBy('id_form_terapi_wicara', 'DESC')
            ->first();
        $data_okupasi_terapi = DB::table('rekam_medis_okupasi_terapi')
            ->where('rekapMedik_id', Session::get('id_rekap') )
            ->orderBy('id_form_okupasi_terapi', 'DESC')
            ->first();
        $data_orthotik = DB::table('rekam_medis_orthotik')
            ->where('rekapMedik_id', Session::get('id_rekap') )
            ->orderBy('id_form_orthotik', 'DESC')
            ->first();

        $data = [
            'identitas'=>Identitas::find(1),
            'active'=>'2',
            'active_sub'=>'',
            'dokter'=>$dokter,
            'content'=>'2',
            'title'=>'Pengkajian Awal Pasien Rawat Jalan',
            'include'=>$include,
            'rekap1'=>$rekap1,
            'form_kebidanan'=> Auth::User()->level == 3 ? $form_kebidanan : (array) [],
            'data_kebidanan'=> !empty($data_kebidanan) ? $data_kebidanan : (object) [],
            'form_fisioterapi'=> Auth::User()->level == 3 ? $form_fisioterapi : (array) [],
            'data_fisioterapi'=> !empty($data_fisioterapi) ? $data_fisioterapi : (object) [],
            'form_terapi_wicara'=> Auth::User()->level == 3 ? $form_terapi_wicara : (array) [],
            'data_terapi_wicara'=> !empty($data_terapi_wicara) ? $data_terapi_wicara : (object) [],
            'form_okupasi_terapi'=> Auth::User()->level == 3 ? $form_okupasi_terapi : (array) [],
            'data_okupasi_terapi'=> !empty($data_okupasi_terapi) ? $data_okupasi_terapi : (object) [],
            'form_orthotik'=> Auth::User()->level == 3 ? $form_orthotik : (array) [],
            'data_orthotik'=> !empty($data_orthotik) ? $data_orthotik : (object) [],
        ];
        return view($view,$data);
    }

    function content3(){
        if(Auth::User()->level=='1'){
            $dokter = '';
            $view = 'admin.pages.add.content';
            $include = 'admin.pages.add.content.tahap4';
        }else if(Auth::User()->level=='2'){
            $dokter = DB::table('login_dokter as l')->join('users as u','u.id','l.user_id')->where('u.id',Auth::User()->id)->first();
            $view = 'dokter.pages.add.content';
            $include = 'dokter.pages.add.content.tahap4';
        }else if(Auth::User()->level=='3'){
            $dokter = DB::table('users')->where('id',Auth::User()->id)->first();
            $view = 'perawat.pages.add.content';
            $include = 'perawat.pages.add.content.tahap4';
        }
        $data = [
            'identitas'=>Identitas::find(1),
            'active'=>'2',
            'active_sub'=>'',
            'dokter'=>$dokter,
            'content'=>'3',
            'title'=>'Formulir Edukasi Pasien & Keluarga Terintegrasi Rawat Jalan',
            'include'=>$include,
        ];
        return view($view,$data);
    }

    function content4(){
        if(Auth::User()->level=='1'){
            $dokter = '';
            $view = 'admin.pages.add.content';
            $include = 'admin.pages.add.content.tahap21';
        }else if(Auth::User()->level=='2'){
            $dokter = DB::table('login_dokter as l')->join('users as u','u.id','l.user_id')->where('u.id',Auth::User()->id)->first();
            $view = 'dokter.pages.add.content';
            $include = 'dokter.pages.add.content.tahap21';
        }else if(Auth::User()->level=='3'){
            $dokter = DB::table('users')->where('id',Auth::User()->id)->first();
            $view = 'perawat.pages.add.content';
            $include = 'perawat.pages.add.content.tahap21';
        }
        $data = [
            'identitas'=>Identitas::find(1),
            'active'=>'2',
            'active_sub'=>'',
            'dokter'=>$dokter,
            'content'=>'4',
            'title'=>'Riwayat Medis Pasien',
            'include'=>$include,
        ];
        return view($view,$data);
    }

    function content5(){
        if(Auth::User()->level=='1'){
            $dokter = '';
            $view = 'admin.pages.add.content';
            $include = 'admin.pages.add.content.tahap5';
        }else if(Auth::User()->level=='2'){
            $dokter = DB::table('login_dokter as l')->join('users as u','u.id','l.user_id')->where('u.id',Auth::User()->id)->first();
            $view = 'dokter.pages.add.content';
            $include = 'dokter.pages.add.content.tahap5';
        }else if(Auth::User()->level=='3'){
            $dokter = DB::table('users')->where('id',Auth::User()->id)->first();
            $view = 'perawat.pages.add.content';
            $include = 'perawat.pages.add.content.tahap5';
        }
        $data = [
            'identitas'=>Identitas::find(1),
            'active'=>'2',
            'active_sub'=>'',
            'dokter'=>$dokter,
            'content'=>'5',
            'title'=>'Riwayat Resep',
            'include'=>$include,
        ];
        return view($view,$data);
    }

    function content6(){
        if(Auth::User()->level=='1'){
            $dokter = '';
            $view = 'admin.pages.add.content';
            $include = 'admin.pages.add.content.tahap6';
        }else if(Auth::User()->level=='2'){
            $dokter = DB::table('login_dokter as l')->join('users as u','u.id','l.user_id')->where('u.id',Auth::User()->id)->first();
            $view = 'dokter.pages.add.content';
            $include = 'dokter.pages.add.content.tahap6';
        }else if(Auth::User()->level=='3'){
            $dokter = DB::table('users')->where('id',Auth::User()->id)->first();
            $view = 'perawat.pages.add.content';
            $include = 'perawat.pages.add.content.tahap6';
        }
        $data = [
            'identitas'=>Identitas::find(1),
            'active'=>'2',
            'active_sub'=>'',
            'dokter'=>$dokter,
            'content'=>'6',
            'title'=>'Hasil Laboratorium',
            'include'=>$include,
        ];
        return view($view,$data);
    }

    function content7(){
        if(Auth::User()->level=='1'){
            $dokter = '';
            $view = 'admin.pages.add.content';
            $include = 'admin.pages.add.content.tahap7';
        }else if(Auth::User()->level=='2'){
            $dokter = DB::table('login_dokter as l')->join('users as u','u.id','l.user_id')->where('u.id',Auth::User()->id)->first();
            $view = 'dokter.pages.add.content';
            $include = 'dokter.pages.add.content.tahap7';
        }else if(Auth::User()->level=='3'){
            $dokter = DB::table('users')->where('id',Auth::User()->id)->first();
            $view = 'perawat.pages.add.content';
            $include = 'perawat.pages.add.content.tahap7';
        }
        $data = [
            'identitas'=>Identitas::find(1),
            'active'=>'2',
            'active_sub'=>'',
            'dokter'=>$dokter,
            'content'=>'7',
            'title'=>'Hasil Radiologi',
            'include'=>$include,
        ];
        return view($view,$data);
    }

    function content8(){
        // if(Auth::User()->level=='1'){
        //     $dokter = '';
        //     $view = 'admin.pages.add.content';
        //     $include = 'admin.pages.add.content.tahap7';
        // }else if(Auth::User()->level=='2'){
            $dokter = DB::table('login_dokter as l')->join('users as u','u.id','l.user_id')->where('u.id',Auth::User()->id)->first();
            $view = 'dokter.pages.add.content';
            $include = 'dokter.pages.add.content.tahap8';
        // }else if(Auth::User()->level=='3'){
        //     $dokter = DB::table('users')->where('id',Auth::User()->id)->first();
        //     $view = 'perawat.pages.add.content';
        //     $include = 'perawat.pages.add.content.tahap7';
        // }
        $data = [
            'identitas'=>Identitas::find(1),
            'active'=>'2',
            'active_sub'=>'',
            'dokter'=>$dokter,
            'content'=>'7',
            'title'=>'Data Tarif & Tindakan',
            'include'=>$include,
        ];
        return view($view,$data);
    }
}
