<div id="myModalRadio" class="modal fade" role="dialog">
  <div class="modal-dialog modal-md">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header" style="background: #00c4ff">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Tambah Hasil Radiologi</h4>
      </div>
      <div class="modal-body">
        <div class="col-lg-12 col-md-12">Keterangan</div>
        <div class="col-lg-12 col-md-12"><textarea class="form-control" name=""></textarea></div>
        <div class="col-lg-12 col-md-12">Upload</div>
        <div class="col-lg-12 col-md-12"><input type="file" name=""></div>
        <div class="clearfix"></div>
      </div>
      <div class="modal-footer">
            <input type="button" class="btn btn-success pull-right" value="Tambah">
      </div>
    </div>

  </div>
</div>